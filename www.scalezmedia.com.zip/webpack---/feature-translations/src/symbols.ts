export const name = 'translations' as const
export const TranslateProviderSymbol = Symbol('TranslateProvider')
