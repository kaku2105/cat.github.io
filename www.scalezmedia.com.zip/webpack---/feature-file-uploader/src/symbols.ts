export const name = 'fileUploader' as const
export const ComponentType = 'FileUploader'
