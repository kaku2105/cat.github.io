export const name = 'currentUrl' as const
