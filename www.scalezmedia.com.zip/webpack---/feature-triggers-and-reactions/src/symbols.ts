export const name = 'triggersAndReactions' as const
export const ReactionCreatorFactorySymbol = Symbol('ReactionCreatorFactory')
export const ReactionsStateApiSymbol = Symbol('ReactionsStateApiSymbol')
