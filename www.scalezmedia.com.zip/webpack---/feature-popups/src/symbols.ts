export const PopupsSymbol = Symbol('Popups')
export const CurrentPopupSymbol = Symbol('CurrentPopup')
export const PopupUtilsSymbol = Symbol('PopupUtils')
export const PopupsLinkUtilsAPISymbol = Symbol('PopupsLinkUtilsAPI')

export const name = 'popups' as const
