export const name = 'languageSelector' as const
