export const Animations = Symbol('Animations')
export const EditorAnimationsSym = Symbol('EditorAnimations')

export const name = 'animations' as const
