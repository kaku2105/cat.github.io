export const name = 'scrollToAnchor' as const
export const SamePageScrollSymbol = Symbol('SamePageScroll')
export const SamePageAnchorPropsResolverSymbol = Symbol('SamePageAnchorPropsResolver')
export const AnchorCompIdProviderSymbol = Symbol('AnchorCompIdProvider')
export const ScrollToAnchorHandlerProviderSymbol = Symbol('ScrollToAnchorHandlerProvider')
