export const name = 'fedopsWixCodeSdk' as const
export const namespace = 'fedops' as const
