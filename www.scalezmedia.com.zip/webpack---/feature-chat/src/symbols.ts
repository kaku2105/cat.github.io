export const name = 'chat' as const
