export const name = 'breadcrumbs' as const
