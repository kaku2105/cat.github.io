export const name = 'pageScroll' as const
