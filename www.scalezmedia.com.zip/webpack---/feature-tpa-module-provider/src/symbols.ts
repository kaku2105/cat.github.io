export const name = 'tpaModuleProvider' as const
