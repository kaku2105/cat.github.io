export const name = 'menuContainer' as const
export const MenuContainerHooksSymbol = Symbol('MenuContainerHooks')
