export const name = 'onloadCompsBehaviors' as const
