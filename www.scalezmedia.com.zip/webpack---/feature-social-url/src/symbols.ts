export const name = 'socialUrl' as const
